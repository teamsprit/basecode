

// function display_Chart() {
//   // Area Chart Example
//   var ctx = document.getElementById("myChart");
//   var myLineChart = new Chart(ctx, {
//     type: 'doughnut',
//     data: {

//       labels: ["Completed", "In-Progress", "Rejected"],
//       datasets: [{
//         data: [30, 20, 10],
//         backgroundColor: ["#2ECC40", "#FFFF00", "#FF4136"]
//       }]
//     },
//     options: {
//       responsive: true,
//       title:{
//           display: false,
//           text: "Requests Dashboard"
//       }
//   }
//   }
//     );

// };

function display_Chart(){
var data= btoa('{"request_type":"get_dashboard_Stats"}')
console.log(data)
$.post("https://eu-gb.functions.appdomain.cloud/api/v1/web/varadashashikumar.a%40cognizant.com_dev/default/training.json",
data).done(function (data,status) {
  var ctx = $('#myChart');
  console.log(data)
  var myLineChart = new Chart(ctx, {
    type: 'doughnut',
    data: {

      labels: ["Completed", "In-Progress", "Rejected"],
      datasets: [{
        data: data.values,
        backgroundColor: ["#2ECC40", "#FFFF00", "#FF4136"]
      }]
    },
    options: {
      responsive: true,
      title:{
          display: false,
          text: "Requests Dashboard"
      }
  }
  });

})};